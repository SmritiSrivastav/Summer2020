var connection = require('./../config');
var express=require('express');
var router=express.Router();

function get_data(user_id,callback){
	connection.query("select experience,qualification,specialization,department_name from doctor inner join department on doctor.department_id=department.department_id where user_id_ref=?",[user_id],function(error,result,field){
							if(error){
								return false;
							}
							else{
								//console.log(result);
								return callback(result);
							}
				
					});
}

//user_id will come from session value
module.exports.profile= function(req,res){
	if(req.session.user_id){
	var user_id=req.session.user_id;
	var ans;
	var answer={};
		connection.query("select user_type,email,phone,age,gender,firstname,lastname from login where user_id=?",[user_id],function(errormain,resultmain,fieldmain){
			if(errormain){res.json({message:"Something went wrong!!"})}
			else{ 
				if(resultmain[0].user_type==1){
					 get_data(user_id, function(result){
									answer= result;
							});
				}
					ans=Object.assign(resultmain,answer);
					//res.end();
				res.json({
					status:true,
					message:ans})
			}
		});
	}
	else{
		res.json({message: "Please login."});
	}
}